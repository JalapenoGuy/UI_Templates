﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SideBarUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string line = "a";
        Storyboard StoryBoard = new Storyboard();
        public MainWindow()
        {
            InitializeComponent();
            DoubleAnimation cc = new DoubleAnimation(0.5, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            move_rect.BeginAnimation(FrameworkElement.OpacityProperty, cc);
        }

        private void Press(object sender, RoutedEventArgs e)
        {
            ObjectShift(move_rect, move_rect.Margin, new Thickness(0, 10, 0, 0));
        }

        public void ObjectShift(DependencyObject Object, Thickness Get, Thickness Set)
        {
            ThicknessAnimation Animation = new ThicknessAnimation()
            {
                From = Get,
                To = Set,
                Duration = TimeSpan.FromMilliseconds(200),
                EasingFunction = Smooth,
            };
            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(MarginProperty));
            StoryBoard.Children.Add(Animation);
            StoryBoard.Begin();
        }

        private IEasingFunction Smooth
        {
            get;
            set;
        }
        = new QuarticEase
        {
            EasingMode = EasingMode.EaseOut
        };

        private void PressA(object sender, RoutedEventArgs e)
        {
            ObjectShift(move_rect, move_rect.Margin, new Thickness(0, 42, 0, 0));
        }

        private void PressB(object sender, RoutedEventArgs e)
        {
            ObjectShift(move_rect, move_rect.Margin, new Thickness(0, 74, 0, 0));
        }

        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Mouse.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void Close(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Minimize(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Grid_MouseEnter(object sender, MouseEventArgs e)
        {
            DoubleAnimation cc = new DoubleAnimation(1, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            move_rect.BeginAnimation(FrameworkElement.OpacityProperty, cc);
        }

        private void Grid_MouseLeave(object sender, MouseEventArgs e)
        {
            DoubleAnimation cc = new DoubleAnimation(0.5, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            move_rect.BeginAnimation(FrameworkElement.OpacityProperty, cc);
        }
    }
}
