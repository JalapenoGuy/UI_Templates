﻿using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using ICSharpCode.AvalonEdit.Search;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ScrollViewer tabScroller;
        public MainWindow()
        {
            InitializeComponent();
            SearchPanel.Install(AvalonText);
            Stream xshd_stream = File.OpenRead(Environment.CurrentDirectory + @"\bin\" + "Lua.xshd");
            XmlTextReader xshd_reader = new XmlTextReader(xshd_stream);
            AvalonText.SyntaxHighlighting = HighlightingLoader.Load(xshd_reader, HighlightingManager.Instance);

            xshd_reader.Close();
            xshd_stream.Close();
            this.EditTabs.Loaded += delegate (object source, RoutedEventArgs e)
            {
                this.EditTabs.GetTemplateItem<Button>("AddTabButton").Click += delegate (object s, RoutedEventArgs f)
                {
                    this.MakeTab("", "New Tab");
                };

                TabItem ti = EditTabs.SelectedItem as TabItem;
                ti.GetTemplateItem<Button>("CloseButton").Visibility = Visibility.Hidden;
                ti.GetTemplateItem<Button>("CloseButton").Width = 0;
                ti.Header = "Main Tab";

                this.tabScroller = this.EditTabs.GetTemplateItem<ScrollViewer>("TabScrollViewer");
            };
            //Upgrade the default web browser
        }

        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }

        private void Rectangle_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }

        private void Rectangle_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                DragMove();
            }
        }

        private async void Rectangle_MouseDown_3(object sender, MouseButtonEventArgs e)
        {
            DoubleAnimation cc = new DoubleAnimation(0, (Duration)TimeSpan.FromSeconds(1));
            cc.EasingFunction = new QuarticEase();
            this.BeginAnimation(FrameworkElement.OpacityProperty, cc);
            await Task.Delay(TimeSpan.FromSeconds(0.5));
            this.Close();
        }

        private void Rectangle_MouseDown_4(object sender, MouseButtonEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }
        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem != null)
            {
                TabItem tabItem2 = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (tabItem2 != null)
                {
                    if (!tabItem.Equals(tabItem2))
                    {
                        TabControl tabControl = tabItem.Parent as TabControl;
                        int insertIndex = tabControl.Items.IndexOf(tabItem2);
                        int num = tabControl.Items.IndexOf(tabItem);
                        tabControl.Items.Remove(tabItem2);
                        tabControl.Items.Insert(num, tabItem2);
                        tabControl.Items.Remove(tabItem);
                        tabControl.Items.Insert(insertIndex, tabItem);
                        tabControl.SelectedIndex = num;
                    }
                    return;
                }
            }
        }

        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {
            this.tabScroller.ScrollToHorizontalOffset(this.tabScroller.HorizontalOffset + (double)(e.Delta / 10));
        }

        private void MoveTab(object sender, MouseEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem == null)
            {
                return;
            }
            if (Mouse.PrimaryDevice.LeftButton == MouseButtonState.Pressed)
            {
                if (VisualTreeHelper.HitTest(tabItem, Mouse.GetPosition(tabItem)).VisualHit is Button)
                {
                    return;
                }
                DragDrop.DoDragDrop(tabItem, tabItem, DragDropEffects.Move);
            }
        }

        private TextEditor current;

        public TextEditor GetCurrent()
        {
            if (this.EditTabs.Items.Count == 0)
            {
                return AvalonText;
            }
            else
            {
                return this.current = (this.EditTabs.SelectedContent as TextEditor);
            }
        }

        public TextEditor MakeEditor()
        {
            TextEditor textEditor = new TextEditor
            {
                ShowLineNumbers = true,
                Background = AvalonText.Background,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 255, byte.MaxValue)),
                Margin = new Thickness(2, 5, -1, -4),
                FontFamily = new FontFamily("Consolas"),
                Style = (this.TryFindResource("TextEditorStyle1") as Style),
                HorizontalScrollBarVisibility = ScrollBarVisibility.Visible,
                VerticalScrollBarVisibility = ScrollBarVisibility.Visible
            };
            textEditor.Options.EnableEmailHyperlinks = false;
            textEditor.Options.EnableHyperlinks = false;
            textEditor.Options.AllowScrollBelowDocument = true;
            Stream xshd_stream = File.OpenRead(Environment.CurrentDirectory + @"\bin\" + "lua.xshd");
            XmlTextReader xshd_reader = new XmlTextReader(xshd_stream);
            textEditor.SyntaxHighlighting = HighlightingLoader.Load(xshd_reader, HighlightingManager.Instance);

            xshd_reader.Close();
            xshd_stream.Close();
            return textEditor;
        }

        public TabItem MakeTab(string text = "", string title = "Tab")
        {
            title = title + " " + EditTabs.Items.Count.ToString();
            bool loaded = false;
            TextEditor textEditor = MakeEditor();
            textEditor.Text = text;
            TabItem tab = new TabItem
            {
                Content = textEditor,
                Style = (base.TryFindResource("Tab") as Style),
                AllowDrop = true,
                Header = title
            };
            tab.MouseWheel += this.ScrollTabs;
            tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (loaded)
                {
                    return;
                }
                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };
            tab.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.MiddleButton == MouseButtonState.Pressed)
                    {
                        this.EditTabs.Items.Remove(tab);
                        return;
                    }
                }
            };

            tab.Loaded += delegate (object s, RoutedEventArgs e)
            {
                tab.GetTemplateItem<Button>("CloseButton").Click += delegate (object r, RoutedEventArgs f)
                {
                    this.EditTabs.Items.Remove(tab);
                };

                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };

            tab.MouseMove += this.MoveTab;
            tab.Drop += this.DropTab;
            string oldHeader = title;
            this.EditTabs.SelectedIndex = this.EditTabs.Items.Add(tab);
            return tab;
        }

        private void Rectangle_MouseDown_5(object sender, MouseButtonEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                this.WindowState = WindowState.Maximized;
            }
            else
            {
                this.WindowState = WindowState.Normal;
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Set.Visibility == Visibility.Hidden)
            {
                Set.Visibility = Visibility.Visible;
                DoubleAnimation animation = new DoubleAnimation();
                animation.From = new double?(0);
                animation.To = new double?(144);
                animation.EasingFunction = new QuarticEase();
                animation.Duration = TimeSpan.FromSeconds(5);
                Set.BeginAnimation(FrameworkElement.WidthProperty, animation);
            }
            else
            {
                DoubleAnimation animation = new DoubleAnimation();
                animation.From = new double?(144);
                animation.To = new double?(0);
                animation.EasingFunction = new QuarticEase();
                animation.Duration = TimeSpan.FromSeconds(5);
                Set.BeginAnimation(FrameworkElement.WidthProperty, animation);
                await Task.Delay(TimeSpan.FromSeconds(3));
                Set.Visibility = Visibility.Hidden;
            }
        }
    }
}
